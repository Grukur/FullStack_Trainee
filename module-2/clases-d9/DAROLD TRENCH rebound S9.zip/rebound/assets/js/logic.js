
function show(){
    document.getElementById('text2').style.display = 'block'
}
function hide(){
    document.getElementById('text2').style.display = 'none'
}
function zoomIn(){
    document.getElementById('img').style.width = '100%'
}
function zoomOut(){
    document.getElementById('img').style.width = '20%'
}
function texto(){
    document.getElementById('text3').style.fontSize = '1.5em'
}
function textoReset(){
    document.getElementById('text3').style.fontSize = '1em'
}